import {useEffect, useState} from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import axios from "axios";
import Home from "./Home";

const api = axios.create({
  baseURL: 'http://localhost:8080'  // Spring Boot 서버 주소
});

function App() {
  return (
    <BrowserRouter>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>  🟣 {/* Link 컴포넌트를 이용하여 경로를 연결한다 */}
            </li>
          </ul>
        </nav>

         <Routes>
          <Route path="/" element={<Home />} /> 
        </Routes>
      </div>
    </BrowserRouter>
  );
}





export default App;